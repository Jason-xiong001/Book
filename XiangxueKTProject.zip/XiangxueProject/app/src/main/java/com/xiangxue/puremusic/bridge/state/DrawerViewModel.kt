package com.xiangxue.puremusic.bridge.state

import androidx.lifecycle.ViewModel

/**
 * 左侧 Fragment 的 DrawerViewModel
 *
 * : ViewModel() 保证数据的稳定性
 */
class DrawerViewModel : ViewModel() {
}