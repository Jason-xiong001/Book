package com.xiangxue.puremusic.bridge.data.repository

/**
 * 为了扩展，这样写（在仓库里面的）
 */
interface ILoadRequest 