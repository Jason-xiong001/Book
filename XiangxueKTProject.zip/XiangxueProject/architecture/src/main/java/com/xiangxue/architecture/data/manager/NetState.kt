package com.xiangxue.architecture.data.manager

/**
 * 网络状态的实体bean
 */
class NetState {
    var responseCode: String? = null
    var isSuccess = true
}