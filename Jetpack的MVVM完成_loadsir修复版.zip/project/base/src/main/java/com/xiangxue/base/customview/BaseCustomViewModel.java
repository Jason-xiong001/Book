package com.xiangxue.base.customview;

public class BaseCustomViewModel {
    public String jumpUri;
    public String title;
}
