package com.xiangxue.common.views.titleview;

import com.xiangxue.base.customview.BaseCustomViewModel;

public class TitleViewModel extends BaseCustomViewModel {
}
